﻿CREATE TABLE [dbo].[Table] (
    [Id]      INT        IDENTITY (1, 1) NOT NULL,
    [Country] NCHAR (10) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

